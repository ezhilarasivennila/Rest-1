package com.example.loggerexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
@SpringBootApplication
public class LoggerExampleApplication {
	private static final Logger LOGGER = LoggerFactory.getLogger(LoggerExampleApplication.class);
	public void displayDate()
	{
		LOGGER.info("Start");
		String date="18-12-31";
		LOGGER.debug(date);
		LOGGER.info("End");
		
	}
	public static void main(String[] args) {
		SpringApplication.run(LoggerExampleApplication.class, args);
		LoggerExampleApplication lea=new LoggerExampleApplication();
		lea.displayDate();
	}

}
