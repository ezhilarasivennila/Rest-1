package com.cognizant.airline.service;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.cognizant.airline.Country;
import com.cognizant.airline.service.exception.CountryNotFoundException;
@Service
public class CountryService {

	public Country getCountry(String code)throws CountryNotFoundException
	{
		ApplicationContext context=new ClassPathXmlApplicationContext("country.xml");
	    List<Country> country=(List<Country>) context.getBean("countryList");
	   try {
		    return country.stream().filter(t->t.getCode().equalsIgnoreCase(code)).findFirst().get();

	   }
	    catch(Exception e)
	   {
	    	throw new CountryNotFoundException();
	   }
	}
	
}
