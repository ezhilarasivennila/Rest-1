package com.cognizant.airline.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.airline.Country;
import com.cognizant.airline.service.CountryService;
import com.cognizant.airline.service.exception.CountryNotFoundException;

@RestController
public class CountryController {
	@Autowired
	CountryService countryservice;
	
	@GetMapping("/countries/{code}")
	public Country getCountry(@PathVariable String code)  throws CountryNotFoundException
	{
	 
	       Country country=countryservice.getCountry(code);
	       return country;
	
	}
}
