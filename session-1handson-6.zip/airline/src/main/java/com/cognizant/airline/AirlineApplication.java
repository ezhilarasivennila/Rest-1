package com.cognizant.airline;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class AirlineApplication {
	public static final Logger LOGGER=LoggerFactory.getLogger(AirlineApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(AirlineApplication.class, args);
		AirlineApplication airlineApplication = new AirlineApplication();
		airlineApplication.displayCountry();
	}

	private void displayCountry() {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");

		List<Country> country = (List<Country>) context.getBean("countryList");
		LOGGER.debug("Country : {}", country);
		LOGGER.info("END");
		
	}

}
