package com.cognizant.airline;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Country {
	private String code;
	private String name;
	public static final Logger LOGGER=LoggerFactory.getLogger(Country.class);
	List<Country> countryList ;
	
	public Country(List<Country> countryList) {
		this.countryList = countryList;
	}
	@Override
	public String toString() {
		return "Country [code=" + getCode() + ", name=" + getName() + "]";
	}
	public Country() {
		// TODO Auto-generated constructor stub

	}
	public Country(String code, String name) {
		super();
		this.setCode(code);
		this.setName(name);
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
