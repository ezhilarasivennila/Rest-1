package com.cognizant.springlearn.controller;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.springlearn.Country;

@RestController
public class CountryController {
	@RequestMapping(value="/country",method=RequestMethod.GET) 
	public String getCountryIndia()
	 {
		 ApplicationContext context =new ClassPathXmlApplicationContext("country.xml");
		 Country country=(Country)context.getBean("in");
		 String res= country.toString();
		 return res;
	 }
	@GetMapping("/countries")
	public String getAllCountries()
	{
		ApplicationContext context= new ClassPathXmlApplicationContext("country.xml");
		ArrayList<Country> countries =(ArrayList<Country>) context.getBean("countryList");
		return countries.toString();
	}

}
