package com.example.listcountry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListcountryApplicationTests {

	@Test
	void contextLoads() {
	}

}
