package com.example.loadconfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import com.example.loggerexample.LoggerExampleApplication;


public class Country {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(Country.class);

	Country(){
	LOGGER.info("Inside Country Constructor");	
	}
	
public String code;
public String name;
public String getCode() {
	LOGGER.info("Inside Getter of Country's code");
	return code;
}
public void setCode(String code) {
	LOGGER.info("Inside Setter of country's code");
	this.code = code;
}
public String getName() {
	LOGGER.info("Inside Getter of Country's name");
	return name;
}
public void setName(String name) {
	LOGGER.info("Inside Setter of Country's name");
	this.name = name;
}
@Override
public String toString() {
	return "Country [code=" + code + ", name=" + name + "]";
}

}
