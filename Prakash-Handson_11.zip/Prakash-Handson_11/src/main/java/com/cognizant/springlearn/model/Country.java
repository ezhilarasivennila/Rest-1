package com.cognizant.springlearn.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.cognizant.springlearn.controller.CountryController;

@Component
public class Country {

	String code;
	String name;
	Logger logger = LoggerFactory.getLogger(CountryController.class);
	
	public String getCode() {
		logger.info("Inside getter method of code");
		return code;
	}
	public void setCode(String code) {
		this.code = code;
		logger.info("Inside setter method of code");
	}
	
	public String getName() {
		logger.info("Inside getter method of name");
		return name;
	}
	public void setName(String name) {
		this.name = name;
		logger.info("Inside setter method of name");
	}
}
