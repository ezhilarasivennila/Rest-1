package com.example.loadconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoadConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
