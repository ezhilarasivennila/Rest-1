package com.cognizant.airline;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class AirlineApplication {
	public static final Logger LOGGER=LoggerFactory.getLogger(AirlineApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(AirlineApplication.class, args);
		AirlineApplication airlineApplication = new AirlineApplication();
		airlineApplication.displayCountry();
	}

	private void displayCountry() {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");

		Country country = (Country) context.getBean("country", Country.class);
		System.out.println(country.toString());
		LOGGER.debug("Country : {}", country.toString());
		
	}

}
