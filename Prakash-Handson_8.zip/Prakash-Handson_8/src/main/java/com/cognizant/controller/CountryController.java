package com.cognizant.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.model.Country;

@RestController
public class CountryController {

	Logger logger = LoggerFactory.getLogger(CountryController.class);
	
	@RequestMapping("/country")
	public Country getCountryIndia()
	{
		logger.info("START");
		logger.info("END");
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
		Country country = context.getBean(Country.class);
		return country;
	}
}
