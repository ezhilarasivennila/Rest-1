package com.cognizant.springlearn;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Country {

	String code;
	String name;
	Logger logger = LoggerFactory.getLogger(Country.class);

	public Country() {
		super();
		logger.debug("Inside Country Constructor");
	}

	public String getCode() {
		logger.debug("Inside getter method for code");
		return code;
	}

	public void setCode(String code) {
		this.code = code;
		logger.debug("Inside setter method for country code");
	}

	public String getName() {
		logger.debug("Inside getter method for name");
		return name;
	}

	public void setName(String name) {
		this.name = name;
		logger.debug("Inside setter method for country name");
	}

	@Override
	public String toString() {
		return "Country [code=" + code + ", name=" + name + "]";
	}
}
