package com.example.scope;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScopeApplicationTests {

	@Test
	void contextLoads() {
	}

}
