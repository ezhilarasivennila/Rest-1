package com.cognizant.springlearn.model;

import lombok.Data;

public @Data class Country {

	private String code,name;
}
