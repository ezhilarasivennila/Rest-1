package com.cognizant.springlearn;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Country 
{
	private static final Logger LOGGER = LoggerFactory.getLogger(Country.class); 
	public String code;
	public String name;
	public Country() 
	{
		LOGGER.info("Inside Country's default Constructor");
	}
	public Country(String code, String name)
	{
		super();
		LOGGER.info("Inside Country's Constructor");
	}
	public String getCode() 
	{
		LOGGER.info("Inside Country's getCode()");
		return code;
	}
	public void setCode(String code)
	{
		LOGGER.info("Inside Country's setCode()");
		this.code = code;
	}
	public String getName()
	{
		LOGGER.info("Inside Country's getName()");
		return name;
	}
	public void setName(String name)
	{
		LOGGER.info("Inside Country's setName()");
		this.name = name;
	}
	@Override
	public String toString()
	{
		return "Country [code=" + code + ", name=" + name + "]";
	}
	
}