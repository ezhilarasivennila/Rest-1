package com.cognizant.springlearn.service;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.cognizant.springlearn.Country;

@Service
public class CountryService 
{
	public Country getCountry(String code)
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
		ArrayList<Country> countries = (ArrayList<Country>) context.getBean("countryList");
		for(Country c:countries) 
		{
			if((c.getCode()).equalsIgnoreCase("IN")) 
			{
				return c;
			}
			else 
			{
				continue;
			}
		}
		return null;
	}
}